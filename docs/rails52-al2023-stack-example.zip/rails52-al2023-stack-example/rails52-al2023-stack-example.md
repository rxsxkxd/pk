# 構成の具体例: Ruby 2.6.5 / Rails 5.2.3 / Apache + Passenger / MySQL / Amazon Linux 2023

- 作成日: 2026-11-09
- 状態: 草案
- 関連: [Rails アプリのインスタンスを構成するもの](../rails-runtime-stack/rails-runtime-stack.md)、[構成の具体例: Ruby 2.3.1 / Rails 4.2 / Apache + Passenger / MySQL / Amazon Linux 2](../rails42-al2-stack-example/rails42-al2-stack-example.md)（以下「4.2 版」）、[構成の具体例: Rails 6.1 へ上げた場合](../rails61-al2023-stack-example/rails61-al2023-stack-example.md)（以下「6.1 版」）

Ruby 2.6.5 と Rails 5.2.3 のアプリを Amazon Linux 2023 の EC2 で動かすときの構成と、各部品のバージョンを示す。Ruby と Rails は古いまま、OS だけがサポート期間内にある構成である。

実機でのビルドや起動は試していない。gem の要求するバージョンは 2026-11 に rubygems.org の情報で確かめた。実機でしか分からない点は「要確認」と書く。

## 1. 前提

### 方針

| 項目 | 方針 |
| --- | --- |
| Ruby | 2.6.5 |
| Rails | 5.2.3 |
| OS | Amazon Linux 2023 |
| 構成の形 | 4.2 版・6.1 版と同じ。Apache + Passenger、MySQL、EC2 |

Ruby、Rails、OS は指定された条件である。構成の形は指定がないため、既存の 2 つの例にそろえて仮に置いた。

### この組み合わせの特徴

- **Ruby 用に OpenSSL 1.1.1 を別に用意する。** Ruby 2.6 は OpenSSL 3 系に対応していない。一方、Amazon Linux 2023 の OpenSSL は 3.0 系である。ruby-build の Ruby 2.6.5 の定義は、OS の OpenSSL が対応範囲外のとき、OpenSSL 1.1.1w を一緒にビルドする（4 章）
- **Ruby も Rails も、各系列の最後の版ではない。** 2.6 系の最後は 2.6.10、5.2 系の最後は 5.2.8.1 である。指定の版には、その後の脆弱性の修正が入っていない（7 章）
- **古い `Gemfile.lock` は、そのままでは入らないことがある。** Rails 5.2.3 の Active Storage が間接的に依存する mimemagic の古い版が、rubygems.org から取り下げられている（6 章）

### バージョンの決まり方

2 章の表の「決まり方」の列は、次の区分で書く。

- **指定**: 1 章で与えられたもの
- **制約**: 指定のバージョンとの組み合わせから、取りうる範囲が決まるもの
- **OS 標準**: Amazon Linux 2023 のパッケージで決まるもの
- **想定**: よくある構成として仮に置いたもの。実際の環境で確かめる

## 2. 全体の重なりと想定バージョン

![Ruby 2.6.5 / Rails 5.2.3 / Amazon Linux 2023 の構成と想定バージョン](images/rails52-al2023-layers.svg)

| 層 | この例 | 想定バージョン | 決まり方 | 入手経路 |
| --- | --- | --- | --- | --- |
| 実行基盤 | Amazon EC2 | — | 想定 | AWS |
| OS | Amazon Linux 2023 のカーネル | 6.1（6.12 も選べる） | OS 標準 | AMI |
| OS のライブラリ | glibc | 2.34 | OS 標準 | dnf |
| | gcc | 11 | OS 標準 | dnf |
| | OpenSSL（Ruby 用） | 1.1.1w | 制約（Ruby 2.6） | ruby-build が Ruby と一緒にビルドする |
| | OpenSSL（OS 標準） | 3.0 系 | OS 標準 | dnf の `openssl` パッケージ。Apache の mod_ssl と MySQL のクライアントが使う |
| | MySQL のクライアントライブラリ | MariaDB Connector/C 3 系 | OS 標準（要確認） | dnf の `mariadb-connector-c` パッケージ |
| | shared-mime-info | OS のパッケージの版 | 制約（mimemagic 0.3.10 のインストールに要る） | dnf |
| | Node.js | 22 系（必要な場合だけ） | 想定 | dnf の `nodejs22` パッケージ |
| Ruby | Ruby | 2.6.5 | 指定 | rbenv / ruby-build でビルド |
| | openssl 拡張 | 2.1 系（Ruby 2.6 に同梱） | 制約（Ruby 2.6） | Ruby に同梱 |
| | RubyGems | 3.0 系（Ruby 2.6 に同梱） | 制約（Ruby 2.6） | Ruby に同梱 |
| gem | Bundler | 1.17 系（Ruby 2.6 に同梱）、または 2.4 系まで | 制約（Ruby 2.6） | Ruby に同梱、または `gem install bundler` |
| | mysql2 | 0.5 系 | 制約（Rails 5.2.3 は 0.4.4 以上 0.6 未満） | rubygems.org |
| | nokogiri | 1.13 系まで | 制約（Ruby 2.6） | rubygems.org |
| | sprockets | 3 系 | 想定 | rubygems.org |
| | marcel | 0.3 系 | 制約（Rails 5.2.3 は `~> 0.3.1`） | rubygems.org |
| | mimemagic | 0.3.10 | 制約（marcel 0.3 系は `~> 0.3.2`。0.3.7 より前は取り下げ済み） | rubygems.org |
| アプリサーバー | Phusion Passenger | 6.0 系（最後の版は 6.0.27） | 想定（Amazon Linux 2023 で動く版かは要確認） | gem と `passenger-install-apache2-module` |
| （Web サーバー） | Apache httpd | 2.4 系 | OS 標準 | dnf |
| フレームワーク | Rails | 5.2.3 | 指定 | rubygems.org |
| | Rack | 2.2 系 | 制約（Rails 5.2.3 は 2 系） | rubygems.org |
| DB サーバー | MySQL | 8.0 | 想定 | RDS など |

## 3. 4.2 版・6.1 版との違い

| 項目 | 4.2 版 | この例 | 6.1 版 |
| --- | --- | --- | --- |
| OS | Amazon Linux 2 | Amazon Linux 2023 | Amazon Linux 2023 |
| Ruby | 2.3.1 | 2.6.5 | 2.7.8 |
| Rails | 4.2.11.3 | 5.2.3 | 6.1.7 系 |
| Ruby が使う OpenSSL | 1.0.2k（OS 標準） | 1.1.1w（自前でビルド） | 1.1.1 系（自前でビルド） |
| Bundler | 1.17.3 を別に入れる | Ruby に同梱の 1.17 系、または 2.4 系まで | 2 系 |
| mysql2 | 0.4.10 | 0.5 系 | 0.5 系 |
| nokogiri | 1.10 系まで | 1.13 系まで | 1.15 系まで |
| sprockets | 3 系 | 3 系 | 4 系 |
| コードの自動読み込み | classic | classic（Zeitwerk は Rails 6.0 から） | Zeitwerk |

OS から下の部品と、Ruby 用の OpenSSL を別に持つ形は 6.1 版と同じである。Rails と gem の世代は、4.2 版と 6.1 版の中間にあたる。Rails 5.2 で入った機能のうち、credentials（`config/credentials.yml.enc` と `config/master.key`）と Active Storage は、配置の手順に関わる。

## 4. OpenSSL が 2 つある

1 台のマシンに 2 つの版が並ぶ形と、その注意点は [6.1 版の 4 章](../rails61-al2023-stack-example/rails61-al2023-stack-example.md#4-openssl-が-2-つあるruby-用を自前でビルドする) と同じである。

| 使う側 | 使う OpenSSL | 影響 |
| --- | --- | --- |
| Ruby の openssl 拡張 | 1.1.1w（自前でビルド） | 外部への HTTPS、Rails の暗号化と署名 |
| mysql2 → MariaDB Connector/C | 3.0（OS 標準） | DB との TLS 接続 |
| Apache の mod_ssl | 3.0（OS 標準） | Apache で TLS を終端する場合 |

- **Ruby 用の OpenSSL 1.1.1w は、OS の更新で直らない。** 本家のサポートは 2023-09-11 に終わっている
- **OS 全体の暗号の方針（crypto-policies）は、Ruby の側には効かない（要確認）。**
- **1 つの Ruby のプロセスに、`libssl.so.1.1` と `libssl.so.3` の両方が読み込まれる。** 名前が違うので通常は共存できるが、実際の環境で確かめる
- **Ruby 用の OpenSSL をなくすには、Ruby 3.1 以降が要る。** Rails 5.2 のままでは現実的でないため、Rails の更新と合わせて考える（8 章）

## 5. プロセスと DB 接続

![Apache と Passenger のプロセスと DB 接続（Rails 5.2 / Amazon Linux 2023）](images/rails52-al2023-processes.svg)

プロセスとスレッドの形は、4.2 版・6.1 版と同じである（[4.2 版の 5 章](../rails42-al2-stack-example/rails42-al2-stack-example.md#5-プロセスと-db-接続)）。

- **DB の接続数**: おおよそ「インスタンス数 × アプリのプロセス数（`PassengerMaxPoolSize`）」
- **Passenger が使う Ruby**: Apache の設定の `PassengerRuby` で、rbenv の Ruby 2.6.5 を指す

## 6. バージョンの組み合わせの制約

| 起点 | 制約 | 内容 |
| --- | --- | --- |
| Rails 5.2.3 | Ruby は 2.2.2 以降 | 2.6 系は範囲に入る |
| Rails 5.2.3 | Bundler は 1.3.0 以降 | 上限はない。Bundler 2 系も使える |
| Rails 5.2.3 | mysql2 は 0.4.4 以上 0.6 未満 | Rails の MySQL アダプターの指定による |
| Rails 5.2.3 | Rack は 2 系 | `rack ~> 2.0` |
| Rails 5.2.3 | marcel は 0.3 系、mimemagic は 0.3 系 | mimemagic は 0.3.7 より前の版が rubygems.org に残っていない。2021 年ごろより前の `Gemfile.lock` は、`bundle install` で失敗する。0.3.10 へ上げる。mimemagic 0.3.10 はインストール時に MIME の定義ファイルを探すので、OS に `shared-mime-info` を入れる |
| Rails 5.2.3 | concurrent-ruby は 1.3.4 までに固定する（要確認） | Rails 側の指定に上限がなく、`Gemfile.lock` を作り直すと 1.3.5 以降が入る。1.3.5 以降では、Rails 7.0 以前で起動時に `Logger` の定数のエラーになる例が知られている |
| Ruby 2.6 | OpenSSL は 1.1.1 系まで | Amazon Linux 2023 では、Ruby 用に 1.1.1w を別にビルドする（4 章） |
| Ruby 2.6 | nokogiri は 1.13 系まで | nokogiri 1.14 から Ruby 2.7 以降が必要 |
| Ruby 2.6 | Bundler は 2.4 系まで | Bundler 2.5 から Ruby 3.0 以降が必要 |
| Ruby 2.6 | ビルドの道具 | Amazon Linux 2023 の gcc 11 と glibc 2.34 で、Ruby 2.6.5 と OpenSSL 1.1.1w がビルドできるかを確かめる（要確認）。Ruby 2.6.5 は 2019 年の版で、これらより古い環境を前提に作られているため、この構成で最初に確かめる点である |
| Amazon Linux 2023 | Passenger の版 | 6.0 系の最後の版は 6.0.27。Amazon Linux 2023 でビルドできて動くかを確かめる。6.1 以降へ上げる場合は、Ruby 2.6 への対応も確かめる（要確認） |
| Node.js 17 以降 | webpack 4 | Rails 5.2 と webpacker の組み合わせで webpack 4 を使うと、OpenSSL 3 の制限でビルドが失敗する。`--openssl-legacy-provider` を付けるか、Node.js の版を見直す。Sprockets と uglifier だけなら、この問題は起きない |
| MySQL 8.0 | 認証方式 | 既定の `caching_sha2_password` にクライアントが対応している必要がある。対応していなければ、接続ユーザーを `mysql_native_password` にする |
| MySQL 8.0 | Rails 5.2.3 との組み合わせ | マイグレーション、`schema.rb` の出力、8.0 で増えた予約語、既定の照合順序 `utf8mb4_0900_ai_ci` の影響を確かめる（要確認） |

## 7. サポート終了の状況（2026-11 時点）

OS と Node.js のほかは、サポートを終えている。

| 部品 | サポート終了 | 補足 |
| --- | --- | --- |
| Rails 5.2 | 2022-06-01 | 最後の版は 5.2.8.1（2022-07-12） |
| Ruby 2.6 | 2022-03-31 | 最後の版は 2.6.10（2022-04-12） |
| OpenSSL 1.1.1（Ruby 用） | 2023-09-11 | 自前でビルドしたものなので、OS の更新でも直らない |
| OpenSSL 3.0（OS 標準） | 2026-09-07（本家） | Amazon Linux 2023 のパッケージとしては、OS のサポート期間中は修正が提供される見込み |
| Amazon Linux 2023 | 2029-06-30 | 期間内 |
| MySQL 8.0 | 2026-04 | RDS では延長サポート（有償）の対象 |
| Node.js 22 | 2027-04-30 | 期間内 |

指定の版は、系列の最後の版より古い。次のような修正が入っていない。

| 部品 | 修正が入った版 | 内容の例 |
| --- | --- | --- |
| Rails | 5.2.4.3 | CVE-2020-8162、8164、8165、8166、8167。8165 は、キャッシュの読み出しでの信頼できないデータのデシリアライズ |
| Rails | 5.2.8.1 | CVE-2022-32224。Active Record のシリアライズした列での YAML のデシリアライズによるコード実行 |
| Ruby | 2.6.6 | CVE-2020-10663（json）、CVE-2020-10933（socket） |
| Ruby | 2.6.9 | CVE-2021-41817（Date）、CVE-2021-41819（CGI::Cookie） |
| Ruby | 2.6.10 | CVE-2022-28739（文字列から浮動小数点数への変換） |

系列の中の更新はアプリへの影響が比較的小さいので、指定の版に固定する理由がなければ、2.6.10 と 5.2.8.1 にしておくのが現実的である。5.2.8.1 では YAML の読み込みの既定が変わるため、シリアライズした列を使っていれば確かめる。

## 8. この構成の前後の道筋（概略）

4.2 版からこの構成へ来る場合は、Rails を 5.2 まで上げ、Ruby を 2.4 以降へ上げてから OS を入れ替える。Ruby 2.3 は OpenSSL 1.1 系に対応していないので、先に OS だけを上げると、Ruby 用に OpenSSL 1.0.2 を用意することになる。

この構成から 6.1 版へは、次の順に進める。OS はすでに Amazon Linux 2023 なので、6.1 版の 8 章の段階 5 は要らない。

| 段階 | 上げるもの | そのままにするもの | 理由 |
| --- | --- | --- | --- |
| 1 | Ruby 2.6.5 → 2.6.10、Rails 5.2.3 → 5.2.8.1 | OS、MySQL | 脆弱性の修正を先に入れる（7 章） |
| 2 | Rails 5.2 → 6.0 → 6.1（1 つずつ） | Ruby 2.6 | Rails 6.0 と 6.1 は Ruby 2.5 以降で動く。途中で Bundler 2 系と Zeitwerk に移る |
| 3 | Ruby 2.6 → 2.7.8 | Rails 6.1 | キーワード引数の警告を、Ruby 3 系に向けて解消する |

ここまで進むと、6.1 版と同じ構成になる。

## 9. 実際の環境で確かめること

| 確かめること | 方法の例 |
| --- | --- |
| OS とカーネル | `cat /etc/os-release`、`uname -r` |
| OS の OpenSSL と暗号の方針 | `openssl version`、`update-crypto-policies --show` |
| Ruby のビルド | `rbenv install 2.6.5` が通るか |
| Ruby がリンクしている OpenSSL | `ruby -ropenssl -e 'puts OpenSSL::OPENSSL_VERSION'`（1.1.1w と出るはず） |
| Ruby が使う証明書の置き場所 | `ruby -ropenssl -e 'puts OpenSSL::X509::DEFAULT_CERT_FILE'` と、外部の HTTPS への接続 |
| mysql2 がリンクしているライブラリ | `ldd $(gem contents mysql2 \| grep 'mysql2\.so$')`（`libssl.so.3` につながるはず） |
| gem のバージョン | `Gemfile.lock` の rails、mysql2、nokogiri、mimemagic、concurrent-ruby、`BUNDLED WITH` |
| gem のインストール | まっさらな環境での `bundle install` |
| アプリの起動 | `RAILS_ENV=production bin/rails runner 'puts Rails.version'` |
| Passenger と Apache | `passenger --version`、`httpd -v`、`passenger-memory-stats` |
| Passenger が使う Ruby | Apache の設定の `PassengerRuby` |
| Node.js | `node -v`（アセットのビルドで使う場合） |
| DB サーバーと認証方式 | `SELECT VERSION();`、`SELECT user, plugin FROM mysql.user;` |
